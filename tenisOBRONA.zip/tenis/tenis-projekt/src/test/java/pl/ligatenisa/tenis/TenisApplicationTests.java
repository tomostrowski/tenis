package pl.ligatenisa.tenis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TenisApplicationTests {

	@Test
	void contextLoads() {
	}

}
