package pl.ligatenisa.tenis.entity;

public enum Role {
    USER,
    ADMIN
}
