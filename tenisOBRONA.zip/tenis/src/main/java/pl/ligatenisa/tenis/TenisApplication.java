package pl.ligatenisa.tenis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TenisApplication {

	public static void main(String[] args) {
		SpringApplication.run(TenisApplication.class, args);
	}

}
